import{a as t}from"../chunks/entry.B_6SzH_l.js";export{t as start};
