import{a as t}from"../chunks/entry.g5sORpjq.js";export{t as start};
