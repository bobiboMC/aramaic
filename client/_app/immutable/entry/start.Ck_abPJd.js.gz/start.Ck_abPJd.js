import{a as t}from"../chunks/entry.B6bjGk8b.js";export{t as start};
