import{a as t}from"../chunks/entry.CyF5z8q7.js";export{t as start};
