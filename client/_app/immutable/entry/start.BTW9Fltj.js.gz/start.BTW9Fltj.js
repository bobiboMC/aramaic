import{a as t}from"../chunks/entry.CoLZU6xf.js";export{t as start};
