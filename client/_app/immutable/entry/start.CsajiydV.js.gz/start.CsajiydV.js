import{a as t}from"../chunks/entry.yZHj-QFM.js";export{t as start};
