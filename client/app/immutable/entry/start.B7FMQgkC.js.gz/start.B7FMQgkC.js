import{a as t}from"../chunks/entry.c8_-AGGb.js";export{t as start};
