import{a as t}from"../chunks/entry.DdYthldI.js";export{t as start};
