import{a as t}from"../chunks/entry.Cn7hFdQ7.js";export{t as start};
